package hefshine.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hefshine.data.entity.Employee;
import hefshine.repository.Employeerepository;

@Service
public class AdminService {
@Autowired
Employeerepository repo;

public String save(List<Employee> elist) {
	repo.saveAll(elist);
	return "Record saved to database";
}

public List<Employee> getdata(){
	return repo.findAll();
}

public String update(int id,Employee newdata) {
	Employee existing=repo.findById(id).orElse(null);
	if(existing==null) {
		return "No data Found in database by given Id";
	}
	if(newdata.getName()==null&& newdata.getEmail()==null && newdata.getDepartment()==null&&newdata.getRole()==null&&newdata.getSalary()==0) {
		return "No New data Found ! Please Enter Data Correctly";
	}
	if(newdata.getName()!=null) {
		existing.setName(newdata.getName());
	}
	if(newdata.getEmail()!=null) {
		existing.setEmail(newdata.getEmail());
	}
	if(newdata.getDepartment()!=null) {
		existing.setDepartment(newdata.getDepartment());
	}
	if(newdata.getRole()!=null) {
		existing.setRole(newdata.getRole());
	}
	if(newdata.getSalary()!=0) {
		existing.setSalary(newdata.getSalary());
	}
	repo.save(existing);
	return "Record Updated";
}

public String deleteEmployee(int id) {
	Employee existing=repo.findById(id).orElse(null);
	if(existing==null) {
		return "No data Found in the database with given id";
	}
	repo.deleteById(id);
	return"Employee record deleted successfully";
}



}
