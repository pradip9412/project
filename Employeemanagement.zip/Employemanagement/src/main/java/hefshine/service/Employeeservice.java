package hefshine.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hefshine.data.entity.Employee;
import hefshine.repository.Employeerepository;

@Service
public class Employeeservice {
@Autowired
Employeerepository repo;

public List<Employee> getEmployee(){
	return repo.findAll();
}
public Employee getbyid(int id) {
	return repo.findById(id).orElse(null);
}

}
