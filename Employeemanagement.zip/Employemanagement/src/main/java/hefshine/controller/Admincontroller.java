package hefshine.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import hefshine.data.entity.Employee;
import hefshine.service.AdminService;

@RestController
@RequestMapping("/admin")
public class Admincontroller {
	
	@Autowired
	AdminService serv;
	@RequestMapping("/add")
	public String save(@RequestBody List<Employee> elist) {
		return serv.save(elist);	
	}
	@RequestMapping("/all")
	public List<Employee> getdata(){
		return serv.getdata();
	}
	@RequestMapping("/update")
	public String update(@RequestParam int id,@RequestBody Employee newdata) {
		return serv.update(id, newdata);
	}
	@RequestMapping("/delete")
	public String deleteEmployee(@RequestParam int id) {
		return serv.deleteEmployee(id);
	}
	

}
