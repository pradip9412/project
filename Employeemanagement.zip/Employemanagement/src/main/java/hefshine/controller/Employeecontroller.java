package hefshine.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import hefshine.data.entity.Employee;
import hefshine.service.Employeeservice;

@RestController
@RequestMapping("/employees")
public class Employeecontroller {
	
	@Autowired
	Employeeservice serv;
	
	@RequestMapping("/all")
	public List<Employee> getEmployee(){
		return serv.getEmployee();
	}
	
	@RequestMapping("/getbyid")
	public Employee getbyid(@RequestParam int id) {
		return serv.getbyid(id);
	}

}
